from module_package import *
import random
from DrissionPage import ChromiumPage, ChromiumOptions

def write_visited_log(url):
    with open(f'Visited_Carolina_urls.txt', 'a', encoding='utf-8') as file:
        file.write(f'{url}\n')


def read_log_file():
    if os.path.exists(f'Visited_Carolina_urls.txt'):
        with open(f'Visited_Carolina_urls.txt', 'r', encoding='utf-8') as read_file:
            return read_file.read().split('\n')
    return []


def random_sleep(min_seconds=1, max_seconds=5):
    sleep_time = random.uniform(min_seconds, max_seconds)
    time.sleep(sleep_time)


if __name__ == '__main__':
    timestamp = datetime.now().date().strftime('%Y%m%d')
    file_name = os.path.basename(__file__).rstrip('.py')
    url = 'https://www.carolina.com/'
    base_url = 'https://www.carolina.com'
    headers = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
        # 'Accept-Encoding': 'gzip, deflate, br, zstd',
        'Accept-Language': 'en-US,en;q=0.9',
        'Cache-Control': 'max-age=0',
        'Connection': 'keep-alive',
        'Cookie': 'sib_cuid=f9bfa3f7-bb99-4d53-9b93-e31d2d79b617; _gcl_au=1.1.143815260.1713870676; _fbp=fb.1.1713870676303.1039358499; userty.core.p.89cc84=__2VySWQiOiIzOTMxY2I0YzcyNmZhMTcyMjhjY2JiYzkzZWZkOWEzZiJ9eyJ1c; hubspotutk=d1ce3404a88b213b8f3d1c5303da6434; lhnContact=0e841d9b-aa89-4142-bcd9-0c6a7f768fe4-24984-NXFAoQd; BVBRANDID=64921e2f-2bd3-4794-a737-3ebb4039539b; acceptCookieTermsCookie=; wp36423="WZXVWDDDDDDCTALMVZA-WZWT-XCVY-ITKC-ATBCHIBBUYIJDgNssDJHkhspgH_JhtDD"; _ga_QTJ7CYYKHD=GS1.1.1714720419.1.1.1714720423.0.0.0; _gid=GA1.2.2035065701.1718714461; lhnStorageType=cookie; __hssrc=1; SSID=CQCpDh0cAAAAAABQlydm2gKDDFCXJ2YzAAAAAAAAAAAAjttyZgDSFc7HAALFchsAUJcnZjAAHisBAmPUJQBQlydmMAA; SSSC=695.G7361018486023455450.51|0.0; serverRoute=vBIwqaYiNYXFvsjzwAejcSUVIWM0PSK5lSQJ2PqwoXvPFM4ju6SZ!215562286!1718803342882-app3; CBSESSIONID=vBIwqaYiNYXFvsjzwAejcSUVIWM0PSK5lSQJ2PqwoXvPFM4ju6SZ!215562286; BVImplmain_site=4902; _hp2_ses_props.324705833=%7B%22ts%22%3A1718803344218%2C%22d%22%3A%22www.carolina.com%22%2C%22h%22%3A%22%2Flab-dishes%2Fsyracuse-watch-glass-plain-2-58-in%2F742320.pr%22%7D; __hstc=5999596.d1ce3404a88b213b8f3d1c5303da6434.1713870678828.1718792584615.1718803346817.50; lhnJWT=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ2aXNpdG9yIiwiZG9tYWluIjoiIiwiZXhwIjoxNzE4ODg5NzQ4LCJpYXQiOjE3MTg4MDMzNDgsImlzcyI6eyJhcHAiOiJqc19zZGsiLCJjbGllbnQiOjI0OTg0LCJjbGllbnRfbGV2ZWwiOiJiYXNpYyIsImxobnhfZmVhdHVyZXMiOltdLCJ2aXNpdG9yX3RyYWNraW5nIjp0cnVlfSwianRpIjoiMGU4NDFkOWItYWE4OS00MTQyLWJjZDktMGM2YTdmNzY4ZmU0IiwicmVzb3VyY2UiOnsiaWQiOiIwZTg0MWQ5Yi1hYTg5LTQxNDItYmNkOS0wYzZhN2Y3NjhmZTQtMjQ5ODQtTlhGQW9RZCIsInR5cGUiOiJFbGl4aXIuTGhuRGIuTW9kZWwuQ29yZS5WaXNpdG9yIn19.gIQLPFXBcWng6U52ppX3GSBr2HpK36lQbbGAFvU39dQ; lhnRefresh=e7675a52-7997-4e9b-9a84-7477ed65693e; SSRT=oehyZgADAA; SSOD=AIDYAAAASAAxWEYAYwEAAFCXJ2ah6HJmJQCM6TgABwAAAANMK2ZD4GZmAABVWzQAAgAAAJCONGa5jjRmAACoqDcAAgAAAJCONGa5jjRmAAAAAA; _ga=GA1.2.259678292.1713870676; _gat_UA-159461-1=1; _ga_2J2J1CBM0T=GS1.1.1718803344.69.1.1718806690.60.0.0; wisepops=%7B%22popups%22%3A%7B%22492430%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1716199760335%2C%22cl%22%3A1%7D%2C%22495677%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1717998220810%2C%22cl%22%3A1%7D%7D%2C%22sub%22%3A0%2C%22ucrn%22%3A53%2C%22cid%22%3A%2248011%22%2C%22v%22%3A4%2C%22bandit%22%3A%7B%22recos%22%3A%7B%7D%7D%7D; _uetsid=04b236002d7011efa64347d26ff72627; _uetvid=3409c3a0016211efb8692f184a9b3ea5; _hp2_id.324705833=%7B%22userId%22%3A%221374166632732052%22%2C%22pageviewId%22%3A%222871232352407604%22%2C%22sessionId%22%3A%221671244194380506%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D; wisepops_visitor=%7B%22JFEHQjxXN3%22%3A%225e155381-f6fa-4d54-9b1c-28e73243d7bf%22%7D; wisepops_visits=%5B%222024-06-19T14%3A18%3A10.408Z%22%2C%222024-06-19T14%3A16%3A08.986Z%22%2C%222024-06-19T14%3A15%3A52.818Z%22%2C%222024-06-19T13%3A52%3A23.088Z%22%2C%222024-06-19T13%3A39%3A22.403Z%22%2C%222024-06-19T13%3A32%3A59.632Z%22%2C%222024-06-19T13%3A32%3A39.224Z%22%2C%222024-06-19T13%3A32%3A23.890Z%22%2C%222024-06-19T13%3A29%3A52.474Z%22%2C%222024-06-19T13%3A29%3A44.207Z%22%5D; wisepops_session=%7B%22arrivalOnSite%22%3A%222024-06-19T14%3A18%3A10.408Z%22%2C%22mtime%22%3A1718806690891%2C%22pageviews%22%3A1%2C%22popups%22%3A%7B%7D%2C%22bars%22%3A%7B%7D%2C%22sticky%22%3A%7B%7D%2C%22countdowns%22%3A%7B%7D%2C%22src%22%3Anull%2C%22utm%22%3A%7B%7D%2C%22testIp%22%3Anull%7D; __hssc=5999596.37.1718803346817; datadome=FYW5P5C2aKnDRL02mycztIqLD2y_dd7p_kkfRQeZGcbqDmSCFPUoEuFLPtt~HImPJT~qEuge~uLOHJxfT8uqspxc3VMwRz~nqqJ7bebeUnIzGpUN6pma3QoTJxPX~WLN; userty.core.s.89cc84=__SI6MTcxODgwODUxNDQ2MSwic2lkIjoiM2EyMzMyNTFlNmEwZTcwMTBlZDdmOWUzMTgxMWE3YzMiLCJzdCI6MTcxODgwMzM0NTk4OCwicmVhZHkiOnRydWUsIndzIjoie1wid1wiOjE1MzYsXCJoXCI6NzMwfSIsInB2IjoyOX0=eyJzZ',
        'Host': 'www.carolina.com',
        'Sec-Ch-Device-Memory': '8',
        'Sec-Ch-Ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
        'Sec-Ch-Ua-Arch': '"x86"',
        'Sec-Ch-Ua-Full-Version-List': '"Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.114", "Google Chrome";v="126.0.6478.114"',
        'Sec-Ch-Ua-Mobile': '?0',
        'Sec-Ch-Ua-Model': '""',
        'Sec-Ch-Ua-Platform': '"Windows"',
        'Sec-Fetch-Dest': 'document',
        'Sec-Fetch-Mode': 'navigate',
        'Sec-Fetch-Site': 'none',
        'Sec-Fetch-User': '?1',
        'Upgrade-Insecure-Requests': '1',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
    }
    soup = get_soup(url, headers)
    content = soup.find('li', class_='nav-item c-nav-menu-link').find_all('li', class_='row c-nav-menu-l1')
    for single_content in content:
        inner_content = single_content.find('div', class_='c-nav-menu-subnav col-12 col-lg-7')
        product_category = inner_content.find('h3', class_='d-none d-lg-block').text.strip()
        if inner_content.find('ul', class_='row'):
            all_urls = inner_content.find('ul', class_='row').find_all('li')
            for single_url in all_urls:
                product_sub_category = single_url.a.text.strip()
                main_url = f"{base_url}{single_url.a['href']}"
                print(f'main_url -----------> {main_url}')
                if main_url in read_log_file():
                    continue
                random_sleep(1, 10)
                inner_request = get_soup(main_url, headers)
                if inner_request is None:
                    continue
                if inner_request.find('div', class_='row px-1'):
                    inner_data = inner_request.find('div', class_='row px-1').find_all('a', class_='c-category-list')
                    for single_data in inner_data:
                        inner_url = f'{base_url}{single_data["href"]}'
                        inner_category = strip_it(single_data.find('h3', class_='c-category-title').text.strip())
                        product_sub_category = f'{product_sub_category}-{inner_category}'
                        random_sleep(1, 5)
                        other_request = get_soup(inner_url, headers)
                        if other_request.find('div', class_='row px-1'):
                            inner_data = other_request.find('div', class_='row px-1').find_all('a', class_='c-category-list')
                            for single_datas in inner_data:
                                inner_process_url = f'{base_url}{single_datas["href"]}'
                                inner_process_request = get_soup(inner_process_url, headers)
                                '''GET PAGINATION'''
                                if inner_process_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg'):
                                    total_page = inner_process_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                                        'li')[-2].text.strip()
                                    for i in range(0, int(total_page)):
                                        number = int(i) * int(60)
                                        page_link = f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={number}&Nr=&'
                                        if page_link in read_log_file():
                                            continue
                                        random_sleep(1, 10)
                                        page_soup = get_soup(page_link, headers)
                                        if page_soup is None:
                                            continue
                                        inner_data = page_soup.find_all('div', class_='c-feature-product qv-model')
                                        for single_data in inner_data:
                                            product_url = f'{base_url}{single_data.find('a')["href"]}'
                                            print(product_url)
                                            random_sleep(1, 10)
                                            product_request = get_soup(product_url, headers)
                                            if product_request is None:
                                                continue
                                            '''IMAGE URL'''
                                            try:
                                                image_href = product_request.find('a', class_='MagicZoom')['href']
                                                if 'http' not in str(image_href):
                                                    image_url = f'https://www.carolina.com{image_href}'
                                                else:
                                                    image_url = image_href
                                            except:
                                                image_url = ''
                                            '''PRODUCT NAME AND PRODUCT QUANTITY'''
                                            try:
                                                product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                                if re.search('Pack of \d+', str(product_name)):
                                                    product_quantity = re.search('Pack of \d+', str(product_name)).group().replace('Pack of', '').strip()
                                                else:
                                                    product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                                            except:
                                                product_name = ''
                                                product_quantity = '1'
                                            '''PRODUCT NAME'''
                                            try:
                                                product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                                            except:
                                                product_id = ''
                                            '''PRODUCT PRICE'''
                                            try:
                                                if product_request.find('span', class_='pdp-order-price'):
                                                    product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                                elif product_request.find('div', class_='pdp-order-price'):
                                                    product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                                else:
                                                    product_price = ''
                                            except Exception as e:
                                                print('product price', e)
                                                product_price = ''
                                            '''PRODUCT DESC'''
                                            try:
                                                if product_request.find('div', class_='col-12 d-none d-md-block'):
                                                    desc_content = product_request.find('div',
                                                                                        class_='col-12 d-none d-md-block')
                                                    product_desc = strip_it(desc_content.text.strip())
                                                elif product_request.find('div', class_='col pdp-desc-detail'):
                                                    desc_content = product_request.find('div', class_='col pdp-desc-detail')
                                                    product_desc = strip_it(desc_content.text.strip())
                                                else:
                                                    product_desc = ''
                                            except:
                                                product_desc = ''
                                            if product_id in read_log_file():
                                                continue
                                            print('current datetime------>', datetime.now())
                                            dictionary = {
                                                'Carolina_product_category': product_category,
                                                'Carolina_product_sub_category': product_sub_category,
                                                'Carolina_product_id': product_id,
                                                'Carolina_product_name': product_name,
                                                'Carolina_product_quantity': product_quantity,
                                                'Carolina_product_price': product_price,
                                                'Carolina_product_url': product_url,
                                                'Carolina_image_url': image_url,
                                                'Carolina_product_desc': product_desc
                                            }
                                            articles_df = pd.DataFrame([dictionary])
                                            articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first',
                                                                        inplace=True)
                                            if os.path.isfile(f'{file_name}.csv'):
                                                articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                                   mode='a')
                                            else:
                                                articles_df.to_csv(f'{file_name}.csv', index=False)
                                            write_visited_log(product_id)
                                        write_visited_log(page_link)
                                else:
                                    inner_data = inner_process_url.find_all('div', class_='c-feature-product qv-model')
                                    for single_data in inner_data:
                                        product_url = f'{base_url}{single_data.find('a')["href"]}'
                                        print(product_url)
                                        random_sleep(1, 10)
                                        product_request = get_soup(product_url, headers)
                                        if product_request is None:
                                            continue
                                        '''IMAGE URL'''
                                        try:
                                            image_href = product_request.find('a', class_='MagicZoom')['href']
                                            if 'http' not in str(image_href):
                                                image_url = f'https://www.carolina.com{image_href}'
                                            else:
                                                image_url = image_href
                                        except:
                                            image_url = ''
                                        '''PRODUCT NAME AND PRODUCT QUANTITY'''
                                        try:
                                            product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                            if re.search('Pack of \d+', str(product_name)):
                                                product_quantity = re.search('Pack of \d+', str(product_name)).group().replace(
                                                    'Pack of', '').strip()
                                            else:
                                                product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                                        except:
                                            product_name = ''
                                            product_quantity = '1'
                                        '''PRODUCT NAME'''
                                        try:
                                            product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                                        except:
                                            product_id = ''
                                        '''PRODUCT PRICE'''
                                        try:
                                            if product_request.find('span', class_='pdp-order-price'):
                                                product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                            elif product_request.find('div', class_='pdp-order-price'):
                                                product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                            else:
                                                product_price = ''
                                        except Exception as e:
                                            print('product price', e)
                                            product_price = ''
                                        '''PRODUCT DESC'''
                                        try:
                                            if product_request.find('div', class_='col-12 d-none d-md-block'):
                                                desc_content = product_request.find('div', class_='col-12 d-none d-md-block')
                                                product_desc = strip_it(desc_content.text.strip())
                                            elif product_request.find('div', class_='col pdp-desc-detail'):
                                                desc_content = product_request.find('div', class_='col pdp-desc-detail')
                                                product_desc = strip_it(desc_content.text.strip())
                                            else:
                                                product_desc = ''
                                        except:
                                            product_desc = ''
                                        if product_id in read_log_file():
                                            continue
                                        print('current datetime------>', datetime.now())
                                        dictionary = {
                                            'Carolina_product_category': product_category,
                                            'Carolina_product_sub_category': product_sub_category,
                                            'Carolina_product_id': product_id,
                                            'Carolina_product_name': product_name,
                                            'Carolina_product_quantity': product_quantity,
                                            'Carolina_product_price': product_price,
                                            'Carolina_product_url': product_url,
                                            'Carolina_image_url': image_url,
                                            'Carolina_product_desc': product_desc
                                        }
                                        articles_df = pd.DataFrame([dictionary])
                                        articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first', inplace=True)
                                        if os.path.isfile(f'{file_name}.csv'):
                                            articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                               mode='a')
                                        else:
                                            articles_df.to_csv(f'{file_name}.csv', index=False)
                                        write_visited_log(product_id)
                        else:
                            '''GET PAGINATION'''
                            if other_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg'):
                                total_page = other_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                                    'li')[-2].text.strip()
                                for i in range(0, int(total_page)):
                                    number = int(i) * int(60)
                                    page_link = f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={number}&Nr=&'
                                    if page_link in read_log_file():
                                        continue
                                    random_sleep(1, 10)
                                    page_soup = get_soup(page_link, headers)
                                    if page_soup is None:
                                        continue
                                    inner_data = page_soup.find_all('div', class_='c-feature-product qv-model')
                                    for single_data in inner_data:
                                        product_url = f'{base_url}{single_data.find('a')["href"]}'
                                        print(product_url)
                                        random_sleep(1, 10)
                                        product_request = get_soup(product_url, headers)
                                        if product_request is None:
                                            continue
                                        '''IMAGE URL'''
                                        try:
                                            image_href = product_request.find('a', class_='MagicZoom')['href']
                                            if 'http' not in str(image_href):
                                                image_url = f'https://www.carolina.com{image_href}'
                                            else:
                                                image_url = image_href
                                        except:
                                            image_url = ''
                                        '''PRODUCT NAME AND PRODUCT QUANTITY'''
                                        try:
                                            product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                            if re.search('Pack of \d+', str(product_name)):
                                                product_quantity = re.search('Pack of \d+', str(product_name)).group().replace('Pack of', '').strip()
                                            else:
                                                product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                                        except:
                                            product_name = ''
                                            product_quantity = '1'
                                        '''PRODUCT NAME'''
                                        try:
                                            product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                                        except:
                                            product_id = ''
                                        '''PRODUCT PRICE'''
                                        try:
                                            if product_request.find('span', class_='pdp-order-price'):
                                                product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                            elif product_request.find('div', class_='pdp-order-price'):
                                                product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                            else:
                                                product_price = ''
                                        except Exception as e:
                                            print('product price', e)
                                            product_price = ''
                                        '''PRODUCT DESC'''
                                        try:
                                            if product_request.find('div', class_='col-12 d-none d-md-block'):
                                                desc_content = product_request.find('div',
                                                                                    class_='col-12 d-none d-md-block')
                                                product_desc = strip_it(desc_content.text.strip())
                                            elif product_request.find('div', class_='col pdp-desc-detail'):
                                                desc_content = product_request.find('div', class_='col pdp-desc-detail')
                                                product_desc = strip_it(desc_content.text.strip())
                                            else:
                                                product_desc = ''
                                        except:
                                            product_desc = ''
                                        if product_id in read_log_file():
                                            continue
                                        print('current datetime------>', datetime.now())
                                        dictionary = {
                                            'Carolina_product_category': product_category,
                                            'Carolina_product_sub_category': product_sub_category,
                                            'Carolina_product_id': product_id,
                                            'Carolina_product_name': product_name,
                                            'Carolina_product_quantity': product_quantity,
                                            'Carolina_product_price': product_price,
                                            'Carolina_product_url': product_url,
                                            'Carolina_image_url': image_url,
                                            'Carolina_product_desc': product_desc
                                        }
                                        articles_df = pd.DataFrame([dictionary])
                                        articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first',
                                                                    inplace=True)
                                        if os.path.isfile(f'{file_name}.csv'):
                                            articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                               mode='a')
                                        else:
                                            articles_df.to_csv(f'{file_name}.csv', index=False)
                                        write_visited_log(product_id)
                                    write_visited_log(page_link)
                            else:
                                inner_data = other_request.find_all('div', class_='c-feature-product qv-model')
                                for single_data in inner_data:
                                    product_url = f'{base_url}{single_data.find('a')["href"]}'
                                    print(product_url)
                                    random_sleep(1, 10)
                                    product_request = get_soup(product_url, headers)
                                    if product_request is None:
                                        continue
                                    '''IMAGE URL'''
                                    try:
                                        image_href = product_request.find('a', class_='MagicZoom')['href']
                                        if 'http' not in str(image_href):
                                            image_url = f'https://www.carolina.com{image_href}'
                                        else:
                                            image_url = image_href
                                    except:
                                        image_url = ''
                                    '''PRODUCT NAME AND PRODUCT QUANTITY'''
                                    try:
                                        product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                        if re.search('Pack of \d+', str(product_name)):
                                            product_quantity = re.search('Pack of \d+', str(product_name)).group().replace(
                                                'Pack of', '').strip()
                                        else:
                                            product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                                    except:
                                        product_name = ''
                                        product_quantity = '1'
                                    '''PRODUCT NAME'''
                                    try:
                                        product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                                    except:
                                        product_id = ''
                                    '''PRODUCT PRICE'''
                                    try:
                                        if product_request.find('span', class_='pdp-order-price'):
                                            product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                        elif product_request.find('div', class_='pdp-order-price'):
                                            product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                        else:
                                            product_price = ''
                                    except Exception as e:
                                        print('product price', e)
                                        product_price = ''
                                    '''PRODUCT DESC'''
                                    try:
                                        if product_request.find('div', class_='col-12 d-none d-md-block'):
                                            desc_content = product_request.find('div', class_='col-12 d-none d-md-block')
                                            product_desc = strip_it(desc_content.text.strip())
                                        elif product_request.find('div', class_='col pdp-desc-detail'):
                                            desc_content = product_request.find('div', class_='col pdp-desc-detail')
                                            product_desc = strip_it(desc_content.text.strip())
                                        else:
                                            product_desc = ''
                                    except:
                                        product_desc = ''
                                    if product_id in read_log_file():
                                        continue
                                    print('current datetime------>', datetime.now())
                                    dictionary = {
                                        'Carolina_product_category': product_category,
                                        'Carolina_product_sub_category': product_sub_category,
                                        'Carolina_product_id': product_id,
                                        'Carolina_product_name': product_name,
                                        'Carolina_product_quantity': product_quantity,
                                        'Carolina_product_price': product_price,
                                        'Carolina_product_url': product_url,
                                        'Carolina_image_url': image_url,
                                        'Carolina_product_desc': product_desc
                                    }
                                    articles_df = pd.DataFrame([dictionary])
                                    articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first', inplace=True)
                                    if os.path.isfile(f'{file_name}.csv'):
                                        articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                           mode='a')
                                    else:
                                        articles_df.to_csv(f'{file_name}.csv', index=False)
                                    write_visited_log(product_id)
                else:
                    '''GET PAGINATION'''
                    if inner_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg'):
                        total_page = inner_request.find('ul', class_='c-pagination pagination justify-content-start pagination-lg').find_all(
                            'li')[-2].text.strip()
                        for i in range(0, int(total_page)):
                            number = int(i) * int(60)
                            page_link = f'{main_url}?Nf=product.cbsLowPrice%7CGT+0.0%7C%7Cproduct.startDate%7CLTEQ+1.71504E12%7C%7Cproduct.startDate%7CLTEQ+1.71504E12&No={number}&Nr=&'
                            if page_link in read_log_file():
                                continue
                            random_sleep(1, 10)
                            page_soup = get_soup(page_link, headers)
                            if page_soup is None:
                                continue
                            inner_data = page_soup.find_all('div', class_='c-feature-product qv-model')
                            for single_data in inner_data:
                                product_url = f'{base_url}{single_data.find('a')["href"]}'
                                print(product_url)
                                random_sleep(1, 10)
                                product_request = get_soup(product_url, headers)
                                if product_request is None:
                                    continue
                                '''IMAGE URL'''
                                try:
                                    image_href = product_request.find('a', class_='MagicZoom')['href']
                                    if 'http' not in str(image_href):
                                        image_url = f'https://www.carolina.com{image_href}'
                                    else:
                                        image_url = image_href
                                except:
                                    image_url = ''
                                '''PRODUCT NAME AND PRODUCT QUANTITY'''
                                try:
                                    product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                    if re.search('Pack of \d+', str(product_name)):
                                        product_quantity = re.search('Pack of \d+', str(product_name)).group().replace('Pack of', '').strip()
                                    else:
                                        product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                                except:
                                    product_name = ''
                                    product_quantity = '1'
                                '''PRODUCT NAME'''
                                try:
                                    product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                                except:
                                    product_id = ''
                                '''PRODUCT PRICE'''
                                try:
                                    if product_request.find('span', class_='pdp-order-price'):
                                        product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                    elif product_request.find('div', class_='pdp-order-price'):
                                        product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                    else:
                                        product_price = ''
                                except Exception as e:
                                    print('product price', e)
                                    product_price = ''
                                '''PRODUCT DESC'''
                                try:
                                    if product_request.find('div', class_='col-12 d-none d-md-block'):
                                        desc_content = product_request.find('div', class_='col-12 d-none d-md-block')
                                        product_desc = strip_it(desc_content.text.strip())
                                    elif product_request.find('div', class_='col pdp-desc-detail'):
                                        desc_content = product_request.find('div',
                                                                            class_='col pdp-desc-detail')
                                        product_desc = strip_it(desc_content.text.strip())
                                    else:
                                        product_desc = ''
                                except:
                                    product_desc = ''
                                if product_id in read_log_file():
                                    continue
                                print('current datetime------>', datetime.now())
                                dictionary = {
                                    'Carolina_product_category': product_category,
                                    'Carolina_product_sub_category': product_sub_category,
                                    'Carolina_product_id': product_id,
                                    'Carolina_product_name': product_name,
                                    'Carolina_product_quantity': product_quantity,
                                    'Carolina_product_price': product_price,
                                    'Carolina_product_url': product_url,
                                    'Carolina_image_url': image_url,
                                    'Carolina_product_desc': product_desc
                                }
                                articles_df = pd.DataFrame([dictionary])
                                articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first',
                                                            inplace=True)
                                if os.path.isfile(f'{file_name}.csv'):
                                    articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                       mode='a')
                                else:
                                    articles_df.to_csv(f'{file_name}.csv', index=False)
                                write_visited_log(product_id)
                            write_visited_log(page_link)
                    else:
                        inner_data = inner_request.find_all('div', class_='c-feature-product qv-model')
                        for single_data in inner_data:
                            product_url = f'{base_url}{single_data.find('a')["href"]}'
                            print(product_url)
                            random_sleep(1, 10)
                            product_request = get_soup(product_url, headers)
                            if product_request is None:
                                continue
                            '''IMAGE URL'''
                            try:
                                image_href = product_request.find('a', class_='MagicZoom')['href']
                                if 'http' not in str(image_href):
                                    image_url = f'https://www.carolina.com{image_href}'
                                else:
                                    image_url = image_href
                            except:
                                image_url = ''
                            '''PRODUCT NAME AND PRODUCT QUANTITY'''
                            try:
                                product_name = strip_it(product_request.find('div', class_='col prod-nav-title').text.strip())
                                if re.search('Pack of \d+', str(product_name)):
                                    product_quantity = re.search('Pack of \d+', str(product_name)).group().replace(
                                        'Pack of', '').strip()
                                else:
                                    product_quantity = strip_it(product_request.find('input', attrs={'name': 'quantity'})['value'])
                            except:
                                product_name = ''
                                product_quantity = '1'
                            '''PRODUCT NAME'''
                            try:
                                product_id = strip_it(product_request.find('span', id='pdp-skuId').text.strip())
                            except:
                                product_id = ''
                            '''PRODUCT PRICE'''
                            try:
                                if product_request.find('span', class_='pdp-order-price'):
                                    product_price = strip_it(product_request.find('span', class_='pdp-order-price').text.strip())
                                elif product_request.find('div', class_='pdp-order-price'):
                                    product_price = strip_it(product_request.find('div', class_='pdp-order-price').text.strip())
                                else:
                                    product_price = ''
                            except Exception as e:
                                print('product price', e)
                                product_price = ''
                            '''PRODUCT DESC'''
                            try:
                                if product_request.find('div', class_='col-12 d-none d-md-block'):
                                    desc_content = product_request.find('div', class_='col-12 d-none d-md-block')
                                    product_desc = strip_it(desc_content.text.strip())
                                elif product_request.find('div', class_='col pdp-desc-detail'):
                                    desc_content = product_request.find('div', class_='col pdp-desc-detail')
                                    product_desc = strip_it(desc_content.text.strip())
                                else:
                                    product_desc = ''
                            except:
                                product_desc = ''
                            if product_id in read_log_file():
                                continue
                            print('current datetime------>', datetime.now())
                            dictionary = {
                                'Carolina_product_category': product_category,
                                'Carolina_product_sub_category': product_sub_category,
                                'Carolina_product_id': product_id,
                                'Carolina_product_name': product_name,
                                'Carolina_product_quantity': product_quantity,
                                'Carolina_product_price': product_price,
                                'Carolina_product_url': product_url,
                                'Carolina_image_url': image_url,
                                'Carolina_product_desc': product_desc
                            }
                            articles_df = pd.DataFrame([dictionary])
                            articles_df.drop_duplicates(subset=['Carolina_product_id', 'Carolina_product_name'], keep='first', inplace=True)
                            if os.path.isfile(f'{file_name}.csv'):
                                articles_df.to_csv(f'{file_name}.csv', index=False, header=False,
                                                   mode='a')
                            else:
                                articles_df.to_csv(f'{file_name}.csv', index=False)
                            write_visited_log(product_id)
                write_visited_log(main_url)
#
# from module_package import *
#
#
# page = '''Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
# Accept-Encoding: gzip, deflate, br, zstd
# Accept-Language: en-US,en;q=0.9
# Cache-Control: max-age=0
# Connection: keep-alive
# Cookie: sib_cuid=f9bfa3f7-bb99-4d53-9b93-e31d2d79b617; _gcl_au=1.1.143815260.1713870676; _fbp=fb.1.1713870676303.1039358499; userty.core.p.89cc84=__2VySWQiOiIzOTMxY2I0YzcyNmZhMTcyMjhjY2JiYzkzZWZkOWEzZiJ9eyJ1c; hubspotutk=d1ce3404a88b213b8f3d1c5303da6434; lhnContact=0e841d9b-aa89-4142-bcd9-0c6a7f768fe4-24984-NXFAoQd; BVBRANDID=64921e2f-2bd3-4794-a737-3ebb4039539b; acceptCookieTermsCookie=; wp36423="WZXVWDDDDDDCTALMVZA-WZWT-XCVY-ITKC-ATBCHIBBUYIJDgNssDJHkhspgH_JhtDD"; _ga_QTJ7CYYKHD=GS1.1.1714720419.1.1.1714720423.0.0.0; _gid=GA1.2.2035065701.1718714461; lhnStorageType=cookie; __hssrc=1; SSID=CQCpDh0cAAAAAABQlydm2gKDDFCXJ2YzAAAAAAAAAAAAjttyZgDSFc7HAALFchsAUJcnZjAAHisBAmPUJQBQlydmMAA; SSSC=695.G7361018486023455450.51|0.0; serverRoute=vBIwqaYiNYXFvsjzwAejcSUVIWM0PSK5lSQJ2PqwoXvPFM4ju6SZ!215562286!1718803342882-app3; CBSESSIONID=vBIwqaYiNYXFvsjzwAejcSUVIWM0PSK5lSQJ2PqwoXvPFM4ju6SZ!215562286; BVImplmain_site=4902; _hp2_ses_props.324705833=%7B%22ts%22%3A1718803344218%2C%22d%22%3A%22www.carolina.com%22%2C%22h%22%3A%22%2Flab-dishes%2Fsyracuse-watch-glass-plain-2-58-in%2F742320.pr%22%7D; __hstc=5999596.d1ce3404a88b213b8f3d1c5303da6434.1713870678828.1718792584615.1718803346817.50; lhnJWT=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOiJ2aXNpdG9yIiwiZG9tYWluIjoiIiwiZXhwIjoxNzE4ODg5NzQ4LCJpYXQiOjE3MTg4MDMzNDgsImlzcyI6eyJhcHAiOiJqc19zZGsiLCJjbGllbnQiOjI0OTg0LCJjbGllbnRfbGV2ZWwiOiJiYXNpYyIsImxobnhfZmVhdHVyZXMiOltdLCJ2aXNpdG9yX3RyYWNraW5nIjp0cnVlfSwianRpIjoiMGU4NDFkOWItYWE4OS00MTQyLWJjZDktMGM2YTdmNzY4ZmU0IiwicmVzb3VyY2UiOnsiaWQiOiIwZTg0MWQ5Yi1hYTg5LTQxNDItYmNkOS0wYzZhN2Y3NjhmZTQtMjQ5ODQtTlhGQW9RZCIsInR5cGUiOiJFbGl4aXIuTGhuRGIuTW9kZWwuQ29yZS5WaXNpdG9yIn19.gIQLPFXBcWng6U52ppX3GSBr2HpK36lQbbGAFvU39dQ; lhnRefresh=e7675a52-7997-4e9b-9a84-7477ed65693e; SSRT=oehyZgADAA; SSOD=AIDYAAAASAAxWEYAYwEAAFCXJ2ah6HJmJQCM6TgABwAAAANMK2ZD4GZmAABVWzQAAgAAAJCONGa5jjRmAACoqDcAAgAAAJCONGa5jjRmAAAAAA; _ga=GA1.2.259678292.1713870676; _gat_UA-159461-1=1; _ga_2J2J1CBM0T=GS1.1.1718803344.69.1.1718806690.60.0.0; wisepops=%7B%22popups%22%3A%7B%22492430%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1716199760335%2C%22cl%22%3A1%7D%2C%22495677%22%3A%7B%22dc%22%3A1%2C%22d%22%3A1717998220810%2C%22cl%22%3A1%7D%7D%2C%22sub%22%3A0%2C%22ucrn%22%3A53%2C%22cid%22%3A%2248011%22%2C%22v%22%3A4%2C%22bandit%22%3A%7B%22recos%22%3A%7B%7D%7D%7D; _uetsid=04b236002d7011efa64347d26ff72627; _uetvid=3409c3a0016211efb8692f184a9b3ea5; _hp2_id.324705833=%7B%22userId%22%3A%221374166632732052%22%2C%22pageviewId%22%3A%222871232352407604%22%2C%22sessionId%22%3A%221671244194380506%22%2C%22identity%22%3Anull%2C%22trackerVersion%22%3A%224.0%22%7D; wisepops_visitor=%7B%22JFEHQjxXN3%22%3A%225e155381-f6fa-4d54-9b1c-28e73243d7bf%22%7D; wisepops_visits=%5B%222024-06-19T14%3A18%3A10.408Z%22%2C%222024-06-19T14%3A16%3A08.986Z%22%2C%222024-06-19T14%3A15%3A52.818Z%22%2C%222024-06-19T13%3A52%3A23.088Z%22%2C%222024-06-19T13%3A39%3A22.403Z%22%2C%222024-06-19T13%3A32%3A59.632Z%22%2C%222024-06-19T13%3A32%3A39.224Z%22%2C%222024-06-19T13%3A32%3A23.890Z%22%2C%222024-06-19T13%3A29%3A52.474Z%22%2C%222024-06-19T13%3A29%3A44.207Z%22%5D; wisepops_session=%7B%22arrivalOnSite%22%3A%222024-06-19T14%3A18%3A10.408Z%22%2C%22mtime%22%3A1718806690891%2C%22pageviews%22%3A1%2C%22popups%22%3A%7B%7D%2C%22bars%22%3A%7B%7D%2C%22sticky%22%3A%7B%7D%2C%22countdowns%22%3A%7B%7D%2C%22src%22%3Anull%2C%22utm%22%3A%7B%7D%2C%22testIp%22%3Anull%7D; __hssc=5999596.37.1718803346817; datadome=FYW5P5C2aKnDRL02mycztIqLD2y_dd7p_kkfRQeZGcbqDmSCFPUoEuFLPtt~HImPJT~qEuge~uLOHJxfT8uqspxc3VMwRz~nqqJ7bebeUnIzGpUN6pma3QoTJxPX~WLN; userty.core.s.89cc84=__SI6MTcxODgwODUxNDQ2MSwic2lkIjoiM2EyMzMyNTFlNmEwZTcwMTBlZDdmOWUzMTgxMWE3YzMiLCJzdCI6MTcxODgwMzM0NTk4OCwicmVhZHkiOnRydWUsIndzIjoie1wid1wiOjE1MzYsXCJoXCI6NzMwfSIsInB2IjoyOX0=eyJzZ
# Host: www.carolina.com
# Sec-Ch-Device-Memory: 8
# Sec-Ch-Ua: "Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"
# Sec-Ch-Ua-Arch: "x86"
# Sec-Ch-Ua-Full-Version-List: "Not/A)Brand";v="8.0.0.0", "Chromium";v="126.0.6478.114", "Google Chrome";v="126.0.6478.114"
# Sec-Ch-Ua-Mobile: ?0
# Sec-Ch-Ua-Model: ""
# Sec-Ch-Ua-Platform: "Windows"
# Sec-Fetch-Dest: document
# Sec-Fetch-Mode: navigate
# Sec-Fetch-Site: none
# Sec-Fetch-User: ?1
# Upgrade-Insecure-Requests: 1
# User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'''
# clean_header(page)