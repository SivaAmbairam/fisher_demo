# import csv
# import re
# import os
# from transformers import BertTokenizer, BertModel
# import torch
# from sklearn.metrics.pairwise import cosine_similarity
#
# model_name = 'bert-base-uncased'
# tokenizer = BertTokenizer.from_pretrained(model_name)
# model = BertModel.from_pretrained(model_name)
#
# def get_sentence_embedding(sentence):
#     inputs = tokenizer(sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
#     input_ids = inputs['input_ids']
#     attention_mask = inputs['attention_mask']
#
#     with torch.no_grad():
#         outputs = model(input_ids, attention_mask=attention_mask)
#
#     last_hidden_state = outputs.last_hidden_state
#     sentence_embedding = torch.mean(last_hidden_state, dim=1)
#
#     return sentence_embedding
#
# def calculate_similarity(sentence1, sentence2):
#     embedding1 = get_sentence_embedding(sentence1)
#     embedding2 = get_sentence_embedding(sentence2)
#     similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
#
#     return similarity[0][0]
#
# color_names = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'silver']
#
# def write_threshold_log(threshold):
#     with open('Completed_Nasco_thresholds.txt', 'a', encoding='utf-8') as file:
#         file.write(f'{threshold}\n')
#
# def read_threshold_log():
#     if os.path.exists('Completed_Nasco_thresholds.txt'):
#         with open('Completed_Nasco_thresholds.txt', 'r', encoding='utf-8') as read_file:
#             return set(read_file.read().split('\n'))
#     return set()
#
# def clean_text(text):
#     for color in color_names:
#         text = re.sub(rf'\b{color}\b', '', text, flags=re.IGNORECASE)
#     text = re.sub(r'\b\d+(\.\d+)?\s*(mL|mm)\b', '', text, flags=re.IGNORECASE)
#     text = re.sub(r'\b\d+\b', '', text)
#     return text.strip()
#
# def get_word_set(text):
#     return set(word for word in re.split(r'\W+', text) if word)
#
# def word_similarity(set1, set2):
#     return len(set1 & set2) / len(set1 | set2)
#
# def match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder):
#     matched_products = []
#     threshold = initial_threshold
#     prev_threshold = None
#
#     output_folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_folder)
#     os.makedirs(output_folder_path, exist_ok=True)
#     completed_thresholds = read_threshold_log()
#
#     while threshold >= 0:
#         if str(threshold) in completed_thresholds:
#             print(f"Threshold {threshold} already processed. Skipping...")
#             threshold = round(threshold - threshold_decrement, 2)
#             continue
#         print(f"Matching products with threshold: {threshold:.2f}")
#         output_file = os.path.join(output_folder_path, f"FlinnVsNasco_{threshold:.2f}.csv")
#
#         if prev_threshold is None or threshold != prev_threshold:
#             unmatched_flinn_products = []
#
#             with open(output_file, 'w', newline='', encoding='utf-8') as master_file:
#                 writer = csv.writer(master_file)
#                 writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name', 'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url', 'Flinn_product_desc', 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id', 'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url', 'Nasco_image_url', 'Nasco_product_desc', 'Match_Score'])
#
#                 for original_flinn_row, flinn_word_set, flinn_desc_set in flinn_products:
#                     original_flinn_product = original_flinn_row['Flinn_product_name']
#                     print(original_flinn_product)
#                     original_flinn_desc = original_flinn_row['Flinn_product_desc']
#                     best_match = None
#                     best_match_score = 0
#
#                     for original_nasco_row, nasco_word_set, nasco_desc_set in nasco_products:
#                         word_sim = word_similarity(flinn_word_set, nasco_word_set)
#
#                         if word_sim > 0.4:
#                             best_match_score = word_sim
#                             best_match = original_nasco_row
#                         else:
#                             desc_word_sim = calculate_similarity(original_flinn_desc, original_nasco_row['Nasco_product_desc'])
#                             if desc_word_sim >= 0.8:
#                                 combined_similarity = word_sim + desc_word_sim
#                                 print(f"{original_flinn_product}----------> Combined Similarity: {combined_similarity} ------------>{original_nasco_row['Nasco_product_name']}")
#                                 best_match_score = combined_similarity
#                                 best_match = original_nasco_row
#
#                     flinn_colors = [color for color in color_names if
#                                     re.search(rf'\b{color}\b', original_flinn_product, re.IGNORECASE)]
#                     nasco_colors = [color for color in color_names if
#                                     best_match and re.search(rf'\b{color}\b', best_match['Nasco_product_name'],
#                                                              re.IGNORECASE)]
#
#                     flinn_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', original_flinn_product, re.IGNORECASE)
#                     nasco_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', best_match['Nasco_product_name'],
#                                              re.IGNORECASE) if best_match else []
#
#                     if best_match_score >= threshold:
#                         if best_match:
#                             if set(flinn_colors) == set(nasco_colors) and set(flinn_ml_mm) == set(nasco_ml_mm):
#                                 writer.writerow([original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'], original_flinn_row['Flinn_product_id'], original_flinn_product, original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'], original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'], original_flinn_row['Flinn_product_desc'], best_match['Nasco_product_category'], best_match['Nasco_product_sub_category'], best_match['Nasco_product_id'], best_match['Nasco_product_name'], best_match['Nasco_product_quantity'], best_match['Nasco_product_price'], best_match['Nasco_product_url'], best_match['Nasco_image_url'], best_match['Nasco_product_desc'], best_match_score])
#                                 print(f"{original_flinn_product} -> {best_match['Nasco_product_name']} (Match Score: {best_match_score}, Colors and mL/mm Match)")
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                             elif set(flinn_colors) == set(nasco_colors):
#                                 writer.writerow([original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'], original_flinn_row['Flinn_product_id'], original_flinn_product, original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'], original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'], original_flinn_row['Flinn_product_desc'], best_match['Nasco_product_category'], best_match['Nasco_product_sub_category'], best_match['Nasco_product_id'], best_match['Nasco_product_name'], best_match['Nasco_product_quantity'], best_match['Nasco_product_price'], best_match['Nasco_product_url'], best_match['Nasco_image_url'], best_match['Nasco_product_desc'], best_match_score])
#                                 print(f"{original_flinn_product} -> {best_match['Nasco_product_name']} (Match Score: {best_match_score}, Colors Match, mL/mm Mismatch)")
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                             else:
#                                 writer.writerow([original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'], original_flinn_row['Flinn_product_id'], original_flinn_product, original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'], original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'], original_flinn_row['Flinn_product_desc'], best_match['Nasco_product_category'], best_match['Nasco_product_sub_category'], best_match['Nasco_product_id'], best_match['Nasco_product_name'], best_match['Nasco_product_quantity'], best_match['Nasco_product_price'], best_match['Nasco_product_url'], best_match['Nasco_image_url'], best_match['Nasco_product_desc'], best_match_score])
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                     else:
#                         writer.writerow([original_flinn_row['Flinn_product_category'], original_flinn_row['Flinn_product_sub_category'], original_flinn_row['Flinn_product_id'], original_flinn_product, original_flinn_row['Flinn_product_quantity'], original_flinn_row['Flinn_product_price'], original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'], original_flinn_row['Flinn_product_desc'], '', '', '', 'No good match found (Low match score)', '', '', '', '', '', 0])
#                         print(f"{original_flinn_product} -> No good match found (Low match score)")
#                         unmatched_flinn_products.append((original_flinn_row, flinn_word_set))
#
#             flinn_products = unmatched_flinn_products
#             prev_threshold = threshold
#             threshold = round(threshold - threshold_decrement, 2)
#
#         write_threshold_log(prev_threshold)
#
#     return matched_products
#
# with open('Flinn_Products.csv', 'r', encoding='utf-8') as flinn_file, open('Nasco_products.csv', 'r', encoding='utf-8') as nasco_file:
#     flinn_reader = csv.DictReader(flinn_file)
#     nasco_reader = csv.DictReader(nasco_file)
#
#     flinn_products = [(row, get_word_set(clean_text(row['Flinn_product_name'])), get_word_set(clean_text(row['Flinn_product_desc']))) for row in flinn_reader]
#     nasco_products = [(row, get_word_set(clean_text(row['Nasco_product_name'])), get_word_set(clean_text(row['Nasco_product_desc']))) for row in nasco_reader]
#
# initial_threshold = 0.8
# threshold_decrement = 0.01
# output_folder = 'FlinnVsNasco'
#
# matched_products = match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder)
#
# final_output_file = os.path.join(output_folder, 'Matched_Products.csv')
# with open(final_output_file, 'w', newline='', encoding='utf-8') as final_file:
#     writer = csv.writer(final_file)
#     writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name', 'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url', 'Flinn_product_desc', 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id', 'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url', 'Nasco_image_url', 'Nasco_product_url', 'Match_Score'])
#     for match in matched_products:
#         flinn_product, nasco_product, match_score = match
#         writer.writerow([flinn_product['Flinn_product_category'], flinn_product['Flinn_product_sub_category'], flinn_product['Flinn_product_id'], flinn_product['Flinn_product_name'], flinn_product['Flinn_product_quantity'], flinn_product['Flinn_product_price'], flinn_product['Flinn_product_url'], flinn_product['Flinn_image_url'], flinn_product['Flinn_product_desc'], nasco_product['Nasco_product_category'], nasco_product['Nasco_product_sub_category'], nasco_product['Nasco_product_id'], nasco_product['Nasco_product_name'], nasco_product['Nasco_product_quantity'], nasco_product['Nasco_product_price'], nasco_product['Nasco_product_url'], nasco_product['Nasco_image_url'], nasco_product['Nasco_product_desc'], match_score])
#
# print(f"Final matched products have been saved to {final_output_file}")


# import csv
# import re
# import os
#
# import pandas as pd
# from transformers import BertTokenizer, BertModel
# import torch
# import numpy as np
# from sklearn.metrics.pairwise import cosine_similarity
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize
# import nltk
#
# nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')
#
# # Load pre-trained BERT model and tokenizer
# model_name = 'bert-base-uncased'
# tokenizer = BertTokenizer.from_pretrained(model_name)
# model = BertModel.from_pretrained(model_name)
#
# # Get the set of stop words
# stop_words = set(stopwords.words('english'))
#
#
# # Function to remove stop words
# def remove_stop_words(sentence):
#     words = word_tokenize(sentence.lower())
#     filtered_words = [word for word in words if word not in stop_words]
#     filtered_sentence = ' '.join(filtered_words)
#     return filtered_sentence
#
#
# # Function to get sentence embedding
# def get_sentence_embedding(sentence, pooling_strategy='max'):
#     filtered_sentence = remove_stop_words(sentence)
#     inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
#     input_ids = inputs['input_ids']
#     attention_mask = inputs['attention_mask']
#
#     with torch.no_grad():
#         outputs = model(input_ids, attention_mask=attention_mask)
#
#     last_hidden_state = outputs.last_hidden_state
#
#     if pooling_strategy == 'mean':
#         sentence_embedding = torch.mean(last_hidden_state, dim=1)
#     elif pooling_strategy == 'cls':
#         sentence_embedding = last_hidden_state[:, 0, :]
#     elif pooling_strategy == 'max':
#         sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
#     else:
#         raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")
#
#     sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
#     return sentence_embedding
#
#
# # Function to calculate similarity between two sentences
# def calculate_similarity(sentence1, sentence2, pooling_strategy='max'):
#     embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
#     embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
#     similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
#     return similarity[0][0]
#
# color_names = ['red', 'green', 'blue', 'yellow', 'orange', 'purple', 'pink', 'brown', 'black', 'white', 'gray', 'silver']
#
#
# def write_threshold_log(threshold):
#     with open('Completed_Nasco_thresholds.txt', 'a', encoding='utf-8') as file:
#         file.write(f'{threshold}\n')
#
# def read_threshold_log():
#     if os.path.exists('Completed_Nasco_thresholds.txt'):
#         with open('Completed_Nasco_thresholds.txt', 'r', encoding='utf-8') as read_file:
#             return set(read_file.read().split('\n'))
#     return set()
#
# def clean_text(text, phrases_to_remove=None):
#     if phrases_to_remove:
#         for phrase in phrases_to_remove:
#             text = re.sub(rf'\b{re.escape(phrase)}\b', '', text, flags=re.IGNORECASE)
#     text = re.sub(r'\b\d+(\.\d+)?\s*(mL|mm)\b', '', text, flags=re.IGNORECASE)
#     text = re.sub(r'\b\d+\b', '', text)
#     return text.strip()
#
# def get_word_set(text):
#     return set(word for word in re.split(r'\W+', text) if word)
#
# def word_similarity(set1, set2):
#     return len(set1 & set2) / len(set1 | set2)
#
#
# def match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder):
#     matched_products = []
#     threshold = initial_threshold
#     prev_threshold = None
#
#     output_folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_folder)
#     os.makedirs(output_folder_path, exist_ok=True)
#     completed_thresholds = read_threshold_log()
#
#     while threshold >= 0:
#         print(f"Matching products with threshold: {threshold:.2f}")
#         output_file = os.path.join(output_folder_path, f"FlinnVsNasco_{threshold:.2f}.csv")
#
#         if prev_threshold is None or threshold != prev_threshold:
#             unmatched_flinn_products = []
#
#             with open(output_file, 'w', newline='', encoding='utf-8') as master_file:
#                 writer = csv.writer(master_file)
#                 writer.writerow(
#                     ['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name',
#                      'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url',
#                      'Flinn_product_desc', 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id',
#                      'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url',
#                      'Nasco_image_url', 'Nasco_product_desc', 'Match_Score'])
#
#                 for original_flinn_row, flinn_word_set in flinn_products:
#                     original_flinn_product = original_flinn_row['Flinn_product_name']
#                     original_flinn_desc = original_flinn_row['Flinn_product_desc']
#                     best_match = None
#                     best_match_score = 0
#
#                     for original_nasco_row, nasco_word_set in nasco_products:
#                         original_nasco_desc = original_nasco_row['Nasco_product_desc']
#
#                         combined_similarity = calculate_similarity(original_flinn_desc, original_nasco_desc,
#                                                                    pooling_strategy='max')
#
#                         if combined_similarity > best_match_score:
#                             print(f'{original_flinn_product}---------------------{combined_similarity}-----------------{original_nasco_row['Nasco_product_name']}')
#                             best_match_score = combined_similarity
#                             best_match = original_nasco_row
#
#                     flinn_colors = [color for color in color_names if
#                                     re.search(rf'\b{color}\b', original_flinn_product, re.IGNORECASE)]
#                     nasco_colors = [color for color in color_names if
#                                     best_match and re.search(rf'\b{color}\b', best_match['Nasco_product_name'],
#                                                              re.IGNORECASE)]
#
#                     flinn_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', original_flinn_product, re.IGNORECASE)
#                     nasco_ml_mm = re.findall(r'\b\d+(\.\d+)?\s*(mL|mm)\b', best_match['Nasco_product_name'],
#                                              re.IGNORECASE) if best_match else []
#
#                     if best_match_score >= threshold:
#                         if best_match:
#                             if set(flinn_colors) == set(nasco_colors) and set(flinn_ml_mm) == set(nasco_ml_mm):
#                                 writer.writerow([original_flinn_row['Flinn_product_category'],
#                                                  original_flinn_row['Flinn_product_sub_category'],
#                                                  original_flinn_row['Flinn_product_id'], original_flinn_product,
#                                                  original_flinn_row['Flinn_product_quantity'],
#                                                  original_flinn_row['Flinn_product_price'],
#                                                  original_flinn_row['Flinn_product_url'],
#                                                  original_flinn_row['Flinn_image_url'],
#                                                  original_flinn_row['Flinn_product_desc'],
#                                                  best_match['Nasco_product_category'],
#                                                  best_match['Nasco_product_sub_category'],
#                                                  best_match['Nasco_product_id'], best_match['Nasco_product_name'],
#                                                  best_match['Nasco_product_quantity'],
#                                                  best_match['Nasco_product_price'], best_match['Nasco_product_url'],
#                                                  best_match['Nasco_image_url'], best_match['Nasco_product_desc'],
#                                                  best_match_score])
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                             elif set(flinn_colors) == set(nasco_colors):
#                                 writer.writerow([original_flinn_row['Flinn_product_category'],
#                                                  original_flinn_row['Flinn_product_sub_category'],
#                                                  original_flinn_row['Flinn_product_id'], original_flinn_product,
#                                                  original_flinn_row['Flinn_product_quantity'],
#                                                  original_flinn_row['Flinn_product_price'],
#                                                  original_flinn_row['Flinn_product_url'],
#                                                  original_flinn_row['Flinn_image_url'],
#                                                  original_flinn_row['Flinn_product_desc'],
#                                                  best_match['Nasco_product_category'],
#                                                  best_match['Nasco_product_sub_category'],
#                                                  best_match['Nasco_product_id'], best_match['Nasco_product_name'],
#                                                  best_match['Nasco_product_quantity'],
#                                                  best_match['Nasco_product_price'], best_match['Nasco_product_url'],
#                                                  best_match['Nasco_image_url'], best_match['Nasco_product_desc'],
#                                                  best_match_score])
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                             else:
#                                 writer.writerow([original_flinn_row['Flinn_product_category'],
#                                                  original_flinn_row['Flinn_product_sub_category'],
#                                                  original_flinn_row['Flinn_product_id'], original_flinn_product,
#                                                  original_flinn_row['Flinn_product_quantity'],
#                                                  original_flinn_row['Flinn_product_price'],
#                                                  original_flinn_row['Flinn_product_url'],
#                                                  original_flinn_row['Flinn_image_url'],
#                                                  original_flinn_row['Flinn_product_desc'],
#                                                  best_match['Nasco_product_category'],
#                                                  best_match['Nasco_product_sub_category'],
#                                                  best_match['Nasco_product_id'], best_match['Nasco_product_name'],
#                                                  best_match['Nasco_product_quantity'],
#                                                  best_match['Nasco_product_price'], best_match['Nasco_product_url'],
#                                                  best_match['Nasco_image_url'], best_match['Nasco_product_desc'],
#                                                  best_match_score])
#                                 matched_products.append((original_flinn_row, best_match, best_match_score))
#                     else:
#                         writer.writerow([original_flinn_row['Flinn_product_category'],
#                                          original_flinn_row['Flinn_product_sub_category'],
#                                          original_flinn_row['Flinn_product_id'], original_flinn_product,
#                                          original_flinn_row['Flinn_product_quantity'],
#                                          original_flinn_row['Flinn_product_price'],
#                                          original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'],
#                                          original_flinn_row['Flinn_product_desc'], '', '', '',
#                                          'No good match found (Low match score)', '', '', '', '', '', 0])
#                         unmatched_flinn_products.append((original_flinn_row, flinn_word_set))
#
#             flinn_products = unmatched_flinn_products
#             prev_threshold = threshold
#             threshold = round(threshold - threshold_decrement, 2)
#
#     return matched_products
#
#
# with open('Flinn_products.csv', 'r', encoding='utf-8') as flinn_file, open('Nasco_products - Copy.csv', 'r', encoding='utf-8') as nasco_file:
#     flinn_reader = csv.DictReader(flinn_file)
#     nasco_reader = csv.DictReader(nasco_file)
#
#     flinn_products = [(row, get_word_set(clean_text(row['Flinn_product_name']))) for row in flinn_reader]
#     nasco_products = [(row, get_word_set(clean_text(row['Nasco_product_name']))) for row in nasco_reader]
#
# initial_threshold = 0.8
# threshold_decrement = 0.01
# output_folder = 'FlinnVsNasco'
#
# matched_products = match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder)
#
# final_output_file = os.path.join(output_folder, 'Matched_Products.csv')
# with open(final_output_file, 'w', newline='', encoding='utf-8') as final_file:
#     writer = csv.writer(final_file)
#     writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name', 'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url', 'Flinn_product_desc', 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id', 'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url', 'Nasco_image_url', 'Nasco_product_url', 'Match_Score'])
#     for match in matched_products:
#         flinn_product, nasco_product, match_score = match
#         writer.writerow([flinn_product['Flinn_product_category'], flinn_product['Flinn_product_sub_category'], flinn_product['Flinn_product_id'], flinn_product['Flinn_product_name'], flinn_product['Flinn_product_quantity'], flinn_product['Flinn_product_price'], flinn_product['Flinn_product_url'], flinn_product['Flinn_image_url'], flinn_product['Flinn_product_desc'], nasco_product['Nasco_product_category'], nasco_product['Nasco_product_sub_category'], nasco_product['Nasco_product_id'], nasco_product['Nasco_product_name'], nasco_product['Nasco_product_quantity'], nasco_product['Nasco_product_price'], nasco_product['Nasco_product_url'], nasco_product['Nasco_image_url'], nasco_product['Nasco_product_desc'], match_score])
#
# print(f"Final matched products have been saved to {final_output_file}")

import csv
import re
import os
import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import ElementClickInterceptedException
from bs4 import BeautifulSoup
import random
from transformers import BertTokenizer, BertModel
import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import nltk

nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')

# Load pre-trained BERT model and tokenizer
model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertModel.from_pretrained(model_name)


stop_words = set(stopwords.words('english'))

def remove_stop_words(sentence):
    if isinstance(sentence, float):
        return ''
    words = word_tokenize(sentence.lower())
    filtered_words = [word for word in words if word not in stop_words]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence

def get_sentence_embedding(sentence, pooling_strategy='max'):
    filtered_sentence = remove_stop_words(sentence)
    inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']

    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_mask)

    last_hidden_state = outputs.last_hidden_state

    if pooling_strategy == 'mean':
        sentence_embedding = torch.mean(last_hidden_state, dim=1)
    elif pooling_strategy == 'cls':
        sentence_embedding = last_hidden_state[:, 0, :]
    elif pooling_strategy == 'max':
        sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
    else:
        raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")

    sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
    return sentence_embedding

def calculate_similarity(sentence1, sentence2, pooling_strategy='max'):
    embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
    embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
    similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
    return similarity[0][0]

def clean_text(text, phrases_to_remove=None):
    if phrases_to_remove:
        for phrase in phrases_to_remove:
            text = re.sub(rf'\b{re.escape(phrase)}\b', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\b\d+(\.\d+)?\s*(mL|mm)\b', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\b\d+\b', '', text)
    return text.strip()

def get_word_set(text):
    return set(word for word in re.split(r'\W+', text) if word)

def word_similarity(set1, set2):
    return len(set1 & set2) / len(set1 | set2)

def write_threshold_log(threshold):
    with open('Completed_Nasco_thresholds.txt', 'a', encoding='utf-8') as file:
        file.write(f'{threshold}\n')

def read_threshold_log():
    if os.path.exists('Completed_Nasco_thresholds.txt'):
        with open('Completed_Nasco_thresholds.txt', 'r', encoding='utf-8') as read_file:
            return set(read_file.read().split('\n'))
    return set()


def fetch_nasco_product_ids(driver, key_name):
    driver.get('https://www.nascoeducation.com/')
    search_element = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.ID, 'search'))
    )
    search_element.send_keys(key_name)

    search_button = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, "//button[@class='action search']"))
    )

    try:
        driver.execute_script("arguments[0].scrollIntoView(true);", search_button)
        WebDriverWait(driver, 20).until(EC.element_to_be_clickable((By.XPATH, "//button[@class='action search']")))
        search_button.click()
    except ElementClickInterceptedException:
        driver.execute_script("arguments[0].click();", search_button)

    time.sleep(random.randint(1, 20))  # Randomized wait time between 1 and 20 seconds
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    results_number = soup.find_all('strong', class_='kuResultsNumber')
    product_ids = [single_number.text.split(': ', 1)[-1].strip() for single_number in results_number]
    return product_ids


def match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder):
    matched_products = []
    prev_threshold = None
    threshold = initial_threshold

    output_folder_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), output_folder)
    os.makedirs(output_folder_path, exist_ok=True)
    completed_thresholds = read_threshold_log()

    flinn_csv = pd.read_csv('Flinn_products.csv')
    nasco_csv = pd.read_csv('Nasco_products.csv')
    driver = webdriver.Chrome()

    while threshold >= 0:
        if str(threshold) in completed_thresholds:
            print(f"Threshold {threshold} already processed. Skipping...")
            threshold = round(threshold - threshold_decrement, 2)
            continue
        print(f"Matching products with threshold: {threshold:.2f}")
        output_file = os.path.join(output_folder_path, f"FlinnVsNasco_{threshold:.2f}.csv")
        if prev_threshold is None or threshold != prev_threshold:
            unmatched_flinn_products = []

            with open(output_file, 'w', newline='', encoding='utf-8') as master_file:
                writer = csv.writer(master_file)
                writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name',
                                 'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url',
                                 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id',
                                 'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url',
                                 'Nasco_image_url', 'Match_Score'])

                for original_flinn_row, flinn_word_set in flinn_products:
                    original_flinn_product = original_flinn_row['Flinn_product_name']
                    best_match = None
                    best_match_score = 0

                    for original_nasco_row, nasco_word_set in nasco_products:
                        if threshold == 0.4:
                            combined_similarity = word_similarity(flinn_word_set, nasco_word_set)
                            if combined_similarity == 0.4:

                                key_name = original_flinn_row['Flinn_product_name']
                                desc_name = original_flinn_row['Flinn_product_desc']
                                product_ids = fetch_nasco_product_ids(driver, key_name)
                                for product_id in product_ids:
                                    nasco_row = nasco_csv[nasco_csv['Nasco_product_id'] == product_id]
                                    if not nasco_row.empty:
                                        nasco_title = nasco_row.iloc[0]['Nasco_product_name']
                                        nasco_description = nasco_row.iloc[0]['Nasco_product_desc']
                                        title_similarity_score = calculate_similarity(key_name, nasco_title, pooling_strategy='mean')
                                        description_similarity_score = calculate_similarity(desc_name, nasco_description, pooling_strategy='mean')
                                        combined_similarity_score = (title_similarity_score + description_similarity_score) / 2

                                        if combined_similarity_score > best_match_score:
                                            print(f"Word similarity at threshold 0.4: {combined_similarity_score}")
                                            best_match_score = combined_similarity_score
                                            best_match = nasco_row.iloc[0]
                                break
                            else:
                                if combined_similarity > best_match_score:
                                    best_match_score = combined_similarity
                                    best_match = original_nasco_row
                        else:
                            combined_similarity = word_similarity(flinn_word_set, nasco_word_set)
                            if combined_similarity > best_match_score:
                                best_match_score = combined_similarity
                                best_match = original_nasco_row

                    if best_match_score >= threshold:
                        writer.writerow([original_flinn_row['Flinn_product_category'],
                                         original_flinn_row['Flinn_product_sub_category'],
                                         original_flinn_row['Flinn_product_id'], original_flinn_product,
                                         original_flinn_row['Flinn_product_quantity'],
                                         original_flinn_row['Flinn_product_price'],
                                         original_flinn_row['Flinn_product_url'],
                                         original_flinn_row['Flinn_image_url'],
                                         best_match['Nasco_product_category'],
                                         best_match['Nasco_product_sub_category'],
                                         best_match['Nasco_product_id'], best_match['Nasco_product_name'],
                                         best_match['Nasco_product_quantity'],
                                         best_match['Nasco_product_price'], best_match['Nasco_product_url'],
                                         best_match['Nasco_image_url'],
                                         best_match_score])
                        print(f"{original_flinn_product} -> {best_match['Nasco_product_name']} (Match Score: {best_match_score})")
                        matched_products.append((original_flinn_row, best_match, best_match_score))
                    else:
                        writer.writerow([original_flinn_row['Flinn_product_category'],
                                         original_flinn_row['Flinn_product_sub_category'],
                                         original_flinn_row['Flinn_product_id'], original_flinn_product,
                                         original_flinn_row['Flinn_product_quantity'],
                                         original_flinn_row['Flinn_product_price'],
                                         original_flinn_row['Flinn_product_url'], original_flinn_row['Flinn_image_url'], '', '', '',
                                         'No good match found (Low match score)', '', '', '', '', 0])
                        print(f"{original_flinn_product} -> No good match found (Low match score)")
                        unmatched_flinn_products.append((original_flinn_row, flinn_word_set))

            flinn_products = unmatched_flinn_products
            nasco_products = [(nasco_row, nasco_word_set) for nasco_row, nasco_word_set in nasco_products if nasco_row not in [match[1] for match in matched_products]]

            prev_threshold = threshold
            threshold = round(threshold - threshold_decrement, 2)

            write_threshold_log(prev_threshold)

    driver.quit()
    return matched_products


with open('Flinn_products.csv', 'r', encoding='utf-8') as flinn_file, open('Nasco_products.csv', 'r', encoding='utf-8') as nasco_file:
    flinn_reader = csv.DictReader(flinn_file)
    nasco_reader = csv.DictReader(nasco_file)

    flinn_products = [(row, get_word_set(clean_text(row['Flinn_product_name']))) for row in flinn_reader]
    nasco_products = [(row, get_word_set(clean_text(row['Nasco_product_name']))) for row in nasco_reader]

initial_threshold = 0.8
threshold_decrement = 0.1
output_folder = 'FlinnVsNasco'

matched_products = match_products(flinn_products, nasco_products, initial_threshold, threshold_decrement, output_folder)
print(f"Completed matching with {len(matched_products)} products matched.")

final_output_file = os.path.join(output_folder, 'Matched_Products.csv')
with open(final_output_file, 'w', newline='', encoding='utf-8') as final_file:
    writer = csv.writer(final_file)
    writer.writerow(['Flinn_product_category', 'Flinn_product_sub_category', 'Flinn_product_id', 'Flinn_product_name', 'Flinn_product_quantity', 'Flinn_product_price', 'Flinn_product_url', 'Flinn_image_url', 'Nasco_product_category', 'Nasco_product_sub_category', 'Nasco_product_id', 'Nasco_product_name', 'Nasco_product_quantity', 'Nasco_product_price', 'Nasco_product_url', 'Nasco_image_url', 'Match_Score'])
    for match in matched_products:
        flinn_product, nasco_product, match_score = match
        writer.writerow([flinn_product['Flinn_product_category'], flinn_product['Flinn_product_sub_category'], flinn_product['Flinn_product_id'], flinn_product['Flinn_product_name'], flinn_product['Flinn_product_quantity'], flinn_product['Flinn_product_price'], flinn_product['Flinn_product_url'], flinn_product['Flinn_image_url'], flinn_product['Flinn_product_desc'], nasco_product['Nasco_product_category'], nasco_product['Nasco_product_sub_category'], nasco_product['Nasco_product_id'], nasco_product['Nasco_product_name'], nasco_product['Nasco_product_quantity'], nasco_product['Nasco_product_price'], nasco_product['Nasco_product_url'], nasco_product['Nasco_image_url'], match_score])

print(f"Final matched products have been saved to {final_output_file}")







