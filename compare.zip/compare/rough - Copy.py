# import pandas as pd
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
# import time
# from module_package import *
#
#
# if __name__ == '__main__':
#     flinn_csv = pd.read_csv('Flinn_products.csv')
#     nasco_csv = pd.read_csv('Nasco_products.csv')
#     driver = webdriver.Chrome()
#     driver.get('https://www.nascoeducation.com/')
#     key_name = 'Relative Humidity Sensor'
#     send_element = driver.find_element(By.ID, 'search').send_keys(key_name)
#     time.sleep(5)
#     click_button = driver.find_element(By.XPATH, "//button[@class='action search']").click()
#     time.sleep(10)
#     soup = BeautifulSoup(driver.page_source, 'html.parser')
#     number = soup.find_all('strong',  class_='kuResultsNumber')
#     product_ids = []
#     for single_number in number:
#         product_id = single_number.text.split(': ', 1)[-1].strip()
#         product_ids.append(product_id)
#     driver.quit()
#     flinn_csv = pd.read_csv('Flinn_products.csv')
#     nasco_csv = pd.read_csv('Nasco_products.csv')
#     for i, flinn_row in flinn_csv.iterrows():
#         flinn_name = flinn_row['Flinn_product_name']
#         print(flinn_name)


# import pandas as pd
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# from selenium.webdriver.common.keys import Keys
# import time
# from bs4 import BeautifulSoup
# from transformers import BertTokenizer, BertModel
# import torch
# import numpy as np
# from sklearn.metrics.pairwise import cosine_similarity
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize
# import nltk
#
# # Set the NLTK data path to the local directory
# nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')
#
# # Load pre-trained BERT model and tokenizer
# model_name = 'bert-base-uncased'
# tokenizer = BertTokenizer.from_pretrained(model_name)
# model = BertModel.from_pretrained(model_name)
#
# # Get the set of stop words
# stop_words = set(stopwords.words('english'))
#
# def remove_stop_words(sentence):
#     words = word_tokenize(sentence.lower())
#     filtered_words = [word for word in words if word not in stop_words]
#     filtered_sentence = ' '.join(filtered_words)
#     return filtered_sentence
#
# def get_sentence_embedding(sentence, pooling_strategy='mean'):
#     filtered_sentence = remove_stop_words(sentence)
#     inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
#     input_ids = inputs['input_ids']
#     attention_mask = inputs['attention_mask']
#     with torch.no_grad():
#         outputs = model(input_ids, attention_mask=attention_mask)
#     last_hidden_state = outputs.last_hidden_state
#     if pooling_strategy == 'mean':
#         sentence_embedding = torch.mean(last_hidden_state, dim=1)
#     elif pooling_strategy == 'cls':
#         sentence_embedding = last_hidden_state[:, 0, :]
#     elif pooling_strategy == 'max':
#         sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
#     else:
#         raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")
#     sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
#     return sentence_embedding
#
# def calculate_similarity(sentence1, sentence2, pooling_strategy='mean'):
#     embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
#     embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
#     similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
#     return similarity[0][0]
#
# def scrape_nasco_website():
#     driver = webdriver.Chrome()
#     driver.get('https://www.nascoeducation.com/')
#     search_box = driver.find_element(By.ID, 'search')
#     search_box.send_keys('Relative Humidity Sensor')
#     search_box.send_keys(Keys.RETURN)
#     time.sleep(5)
#     soup = BeautifulSoup(driver.page_source, 'html.parser')
#     number = soup.find_all('strong', class_='kuResultsNumber')
#     product_ids = [single_number.text.split(': ', 1)[-1].strip() for single_number in number]
#     driver.quit()
#     return product_ids
#
# def main():
#     nasco_csv = pd.read_csv('Nasco_products.csv')
#     flinn_csv = pd.read_csv('Flinn_products.csv')
#
#     nasco_product_ids = scrape_nasco_website()
#
#     for product_id in nasco_product_ids:
#         nasco_row = nasco_csv[nasco_csv['Nasco_product_id'] == product_id]
#         if not nasco_row.empty:
#             nasco_title = nasco_row.iloc[0]['Nasco_product_name']
#             nasco_description = nasco_row.iloc[0]['Nasco_product_desc']
#             best_similarity_score = 0
#             best_flinn_description = None
#             for flinn_index, flinn_row in flinn_csv.iterrows():
#                 flinn_title = flinn_row['Flinn_product_name']
#                 flinn_description = flinn_row['Flinn_product_desc']
#                 similarity_score = calculate_similarity(nasco_description, flinn_description)
#                 if similarity_score > best_similarity_score:
#                     best_similarity_score = similarity_score
#                     best_flinn_description = flinn_title
#             if best_similarity_score > 0.8:
#                 print(f"Best match for Nasco Product ID: {product_id}")
#                 print(f"Similarity Score: {best_similarity_score}")
#                 print(f"Nasco Description: {nasco_title}")
#                 print(f"Best Flinn Description: {best_flinn_description}")
#
# if __name__ == '__main__':
#     main()


# import pandas as pd
# from selenium import webdriver
# from selenium.webdriver.common.by import By
# import time
# from bs4 import BeautifulSoup
# from transformers import BertTokenizer, BertModel
# import torch
# from sklearn.metrics.pairwise import cosine_similarity
# from nltk.corpus import stopwords
# from nltk.tokenize import word_tokenize
# import nltk
#
# # Load NLTK data path
# nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')
#
# # Load pre-trained BERT model and tokenizer
# model_name = 'bert-base-uncased'
# tokenizer = BertTokenizer.from_pretrained(model_name)
# model = BertModel.from_pretrained(model_name)
#
# # Get the set of stop words
# stop_words = set(stopwords.words('english'))
#
# def remove_stop_words(sentence):
#     words = word_tokenize(sentence.lower())
#     filtered_words = [word for word in words if word not in stop_words]
#     filtered_sentence = ' '.join(filtered_words)
#     return filtered_sentence
#
# def get_sentence_embedding(sentence, pooling_strategy='mean'):
#     filtered_sentence = remove_stop_words(sentence)
#     inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
#     input_ids = inputs['input_ids']
#     attention_mask = inputs['attention_mask']
#     with torch.no_grad():
#         outputs = model(input_ids, attention_mask=attention_mask)
#     last_hidden_state = outputs.last_hidden_state
#     if pooling_strategy == 'mean':
#         sentence_embedding = torch.mean(last_hidden_state, dim=1)
#     elif pooling_strategy == 'cls':
#         sentence_embedding = last_hidden_state[:, 0, :]
#     elif pooling_strategy == 'max':
#         sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
#     else:
#         raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")
#     sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
#     return sentence_embedding
#
# def calculate_similarity(sentence1, sentence2, pooling_strategy='mean'):
#     embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
#     embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
#     similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
#     return similarity[0][0]
#
#
# if __name__ == '__main__':
#     flinn_csv = pd.read_csv('Flinn_products.csv')
#     nasco_csv = pd.read_csv('Nasco_products.csv')
#
#     driver = webdriver.Chrome()
#     driver.get('https://www.nascoeducation.com/')
#     key_name = 'WhiteBox Learning® Prosthetics Kit'
#     # key_name = 'Arduino Complete Starter Kit'
#     desc_name = 'Give students a taste of working in biophysics, biotechnology and the biomedical field with the Prosthetics Kit. This great hands-on activity with medical prosthetic devices helps students learn important STEM concepts, including biophysics, rotational inertia, levers and bio-medicine. Enhance the experience with the WhiteBox Learning standards-based, cloud-based Prosthetics STEM Software Application (available separately). This software lets students â€œconnect the virtual to the physicalâ€ by engineering, analyzing and simulating their designs virtually then printing templates to scale and building physical models. Metric ruler, drill or drill press, Â¼" drill bit, 3/16" drill bit, masking tape, hobby saw and cutting board are required but not included.'
#     send_element = driver.find_element(By.ID, 'search').send_keys(key_name)
#     time.sleep(10)
#     click_button = driver.find_element(By.XPATH, "//button[@class='action search']").click()
#     time.sleep(10)
#     soup = BeautifulSoup(driver.page_source, 'html.parser')
#     number = soup.find_all('strong', class_='kuResultsNumber')
#     product_ids = []
#     for single_number in number:
#         product_id = single_number.text.split(': ', 1)[-1].strip()
#         product_ids.append(product_id)
#
#     driver.quit()
#     best_similarity_score = 0
#     best_flinn_description = None
#     for product_id in product_ids:
#         nasco_row = nasco_csv[nasco_csv['Nasco_product_id'] == product_id]
#         if not nasco_row.empty:
#             nasco_title = nasco_row.iloc[0]['Nasco_product_name']
#             nasco_description = nasco_row.iloc[0]['Nasco_product_desc']
#
#             similarity_score = calculate_similarity(key_name, nasco_title, pooling_strategy='mean')
#             # print(similarity_score)
#             if similarity_score > best_similarity_score:
#                 best_similarity_score = similarity_score
#                 best_flinn_description = key_name
#                 print(f"Best match for Nasco Product ID: {product_id}")
#                 print(f"Similarity Score: {best_similarity_score}")
#                 print(f"Nasco Description: {nasco_title}")
#                 print(f"Best Flinn Description: {best_flinn_description}")


import pandas as pd
from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import random
from bs4 import BeautifulSoup
from transformers import BertTokenizer, BertModel
import torch
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import nltk

# Load NLTK data path
nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')

# Load pre-trained BERT model and tokenizer
model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertModel.from_pretrained(model_name)

# Get the set of stop words
stop_words = set(stopwords.words('english'))


def remove_stop_words(sentence):
    words = word_tokenize(sentence.lower())
    filtered_words = [word for word in words if word not in stop_words and word.isalnum()]
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence


def get_sentence_embedding(sentence, pooling_strategy='mean'):
    filtered_sentence = remove_stop_words(sentence)
    inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']
    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_mask)
    last_hidden_state = outputs.last_hidden_state
    if pooling_strategy == 'mean':
        sentence_embedding = torch.mean(last_hidden_state, dim=1)
    elif pooling_strategy == 'cls':
        sentence_embedding = last_hidden_state[:, 0, :]
    elif pooling_strategy == 'max':
        sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
    else:
        raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")
    sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)
    return sentence_embedding


def calculate_similarity(sentence1, sentence2, pooling_strategy='mean'):
    embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
    embedding2 = get_sentence_embedding(sentence2, pooling_strategy)
    similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())
    return similarity[0][0]


def fetch_nasco_product_ids(driver, key_name):
    driver.get('https://www.nascoeducation.com/')
    search_element = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.ID, 'search'))
    )
    search_element.send_keys(key_name)

    # Scroll the search button into view before clicking
    search_button = WebDriverWait(driver, 20).until(
        EC.presence_of_element_located((By.XPATH, "//button[@class='action search']"))
    )
    driver.execute_script("arguments[0].scrollIntoView(true);", search_button)
    search_button.click()

    time.sleep(random.randint(1, 20))  # Randomized wait time between 5 and 10 seconds
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    results_number = soup.find_all('strong', class_='kuResultsNumber')
    product_ids = [single_number.text.split(': ', 1)[-1].strip() for single_number in results_number]
    print(product_ids)
    return product_ids


if __name__ == '__main__':
    # Load CSV files
    flinn_csv = pd.read_csv('Flinn_products.csv')
    nasco_csv = pd.read_csv('Nasco_products.csv')

    # Initialize WebDriver
    driver = webdriver.Chrome()


    for index, row in flinn_csv.iterrows():
        key_name = row['Flinn_product_name']
        random.randint(1, 10)
        desc_name = row['Flinn_product_desc']
        best_similarity_score = 0
        best_flinn_product = None
        best_nasco_product_id = None
        product_ids = fetch_nasco_product_ids(driver, key_name)
        for product_id in product_ids:
            nasco_row = nasco_csv[nasco_csv['Nasco_product_id'] == product_id]
            if not nasco_row.empty:
                nasco_title = nasco_row.iloc[0]['Nasco_product_name']
                nasco_description = nasco_row.iloc[0]['Nasco_product_desc']

                # Compare both title and description for more accurate match
                title_similarity_score = calculate_similarity(key_name, nasco_title, pooling_strategy='mean')
                description_similarity_score = calculate_similarity(desc_name, nasco_description,
                                                                    pooling_strategy='mean')
                combined_similarity_score = (title_similarity_score + description_similarity_score) / 2

                if combined_similarity_score > best_similarity_score:
                    best_similarity_score = combined_similarity_score
                    best_flinn_product = key_name
                    best_nasco_product_id = product_id

        if best_flinn_product:
            best_nasco_row = nasco_csv[nasco_csv['Nasco_product_id'] == best_nasco_product_id].iloc[0]
            print(f"Best Nasco Product Name: {best_nasco_row['Nasco_product_name']}")
            print(f"Best Nasco Product Description: {best_nasco_row['Nasco_product_desc']}")
            print(f"Best Flinn Product Name: {best_flinn_product}")
            print(f"Highest Similarity Score: {best_similarity_score}")





