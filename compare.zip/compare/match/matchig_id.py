import pandas as pd

if __name__ == '__main__':

    demo_df = pd.read_csv('FlinnVsNasco_0.40.csv')
    flinn_df = pd.read_csv('Flinn_products.csv')

    combined_matches = []

    for i, demo_row in demo_df.iterrows():
        if demo_row['Match_Score'] == 0.4:
            demo_flinn_id = demo_row['Flinn_product_id']
            print(demo_flinn_id)
            flinn_match = {}

            if not pd.isna(demo_flinn_id):
                demo_flinn_id = str(demo_flinn_id)
                flinn_match = flinn_df[flinn_df['Flinn_product_id'].astype(str) == demo_flinn_id].to_dict(orient='records')

            if flinn_match:
                best_match_flinn = flinn_match[0]
                combined_match = {**best_match_flinn}
                combined_matches.append(combined_match)
    combined_df = pd.DataFrame(combined_matches)
    combined_df.to_csv('Master_file.csv', index=False)