from transformers import BertTokenizer, BertModel
import torch
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import nltk

# Set the NLTK data path to the local directory
nltk.data.path.append(r'C:\Users\G6\PycharmProjects\Web-Scrapping_v2\Nasco\compare')

# Load pre-trained BERT model and tokenizer
model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = BertModel.from_pretrained(model_name)

# Get the set of stop words
stop_words = set(stopwords.words('english'))


def remove_stop_words(sentence):
    # Tokenize the sentence into words
    words = word_tokenize(sentence.lower())
    # Remove stop words
    filtered_words = [word for word in words if word not in stop_words]
    # Reconstruct the sentence from filtered words
    filtered_sentence = ' '.join(filtered_words)
    return filtered_sentence


def get_sentence_embedding(sentence, pooling_strategy='mean'):
    # Remove stop words from the sentence
    filtered_sentence = remove_stop_words(sentence)

    # Tokenize the sentence and get the input IDs and attention mask
    inputs = tokenizer(filtered_sentence, return_tensors='pt', truncation=True, padding=True, max_length=128)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']

    # Get the hidden states from the BERT model
    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_mask)

    # The last hidden state is used as the embedding
    last_hidden_state = outputs.last_hidden_state

    if pooling_strategy == 'mean':
        # Take the mean of the token embeddings as the sentence embedding
        sentence_embedding = torch.mean(last_hidden_state, dim=1)
    elif pooling_strategy == 'cls':
        # Use the [CLS] token embedding as the sentence embedding
        sentence_embedding = last_hidden_state[:, 0, :]
    elif pooling_strategy == 'max':
        # Use max pooling over the token embeddings
        sentence_embedding = torch.max(last_hidden_state, dim=1)[0]
    else:
        raise ValueError(f"Unknown pooling strategy: {pooling_strategy}")

    # Normalize the sentence embedding
    sentence_embedding = torch.nn.functional.normalize(sentence_embedding, p=2, dim=1)

    return sentence_embedding


def calculate_similarity(sentence1, sentence2, pooling_strategy='mean'):
    # Get embeddings for both sentences
    embedding1 = get_sentence_embedding(sentence1, pooling_strategy)
    embedding2 = get_sentence_embedding(sentence2, pooling_strategy)

    # Calculate cosine similarity
    similarity = cosine_similarity(embedding1.numpy(), embedding2.numpy())

    return similarity[0][0]


# Example usage
sentence1 = "Affordably and easily explore wind energy with the Advanced Wind Energy Kit. Students gain an understanding of wind power and discover advanced concepts of wind turbine technology as they test a variety of blade designs."
# sentence2 = "Explore stoichiometry, reaction rates, and other chemistry concepts by generating hydrogen from wind power. Use angular velocity, drag force, and other physics concepts to design and build an efficient wind turbine."
sentence3 = "Grades 3 and Up. For your STEM curriculum. Discover how the wind provides us with an endless source of energy and then build a working turbine. Students will assemble a wind turbine complete with an electric generator and adjustable rotor blades designed to look and work like modern-day wind turbine blades. Then conduct experiments to optimize the turbine's performance and discover how to use the turbine to light up an LED and recharge a battery. Includes full-color, 32-page manual with illustrated instructions and scientific information about windmills, wind turbines, wind energy and more."
# sentence3 = "Grades 2-12.Inventor's kit is a great way to introduce programming and hardware interaction with the Arduino into your STEM/STEAM or coding program. Arduino is an open-source codable electronics platform designed for anyone making interactive projects. The Arduino board can process inputs from many sensors, and also controls outputs such as LEDs and motors. Students will use the Arduino development environment to write code in the Arduino programming language, then transfer the code to the Arduino board using a simple USB lead. An easy-to-follow tutorial book guides students through creating 10 experiments using LEDs, motors, LDRs, and capacitors. No soldering is required, allowing students to build their first circuit in minutes. Contains small prototype breadboard for fast prototyping and materials to complete 10 experiments. Required but not included: Arduino board such as the Maker Uno Plus, Phillips screwdriver, terminal block screwdriver, and micro USB cable.Kit Components Mounting plate 7 segment display Potentiometer - vertical type (finger adjust) 100K Finger adjust spindle 4 plastic spacers, 3/8 in. (10 mm) Small prototype breadboard Terminal connector 4 push switches Motor Transistor 2 red LEDs, 3/16 in. (5 mm) 2 orange LEDs, 3/16 in. (5 mm) 2 yellow LEDs, 3/16 in. (5 mm) 2 green LEDs, 3/16 in. (5 mm) RGB LED, 3/16 in. (5 mm) Fan blade 5 2.2K resistors 5 10K resistors 10 220 resistors 20 male to male jumper wires 470uF electrolytic capacitor Piezo element buzzer 4 pan head M3 machine screws PhototransistorSpecifications Grades 2 and up WARNING: Choking Hazard. Small Parts. Not for children under 3 yrs."
# sentence3 = "Grades 2-12.Inventor's kit is a great way to introduce programming and hardware interaction with the Arduino into your STEM/STEAM or coding program. Arduino is an open-source codable electronics platform designed for anyone making interactive projects. The Arduino board can process inputs from many sensors, and also controls outputs such as LEDs and motors. Students will use the Arduino development environment to write code in the Arduino programming language, then transfer the code to the Arduino board using a simple USB lead. An easy-to-follow tutorial book guides students through creating 10 experiments using LEDs, motors, LDRs, and capacitors. No soldering is required, allowing students to build their first circuit in minutes. Contains small prototype breadboard for fast prototyping and materials to complete 10 experiments. Required but not included: Arduino board such as the Maker Uno Plus, Phillips screwdriver, terminal block screwdriver, and micro USB cable.Kit Components Mounting plate 7 segment display Potentiometer - vertical type (finger adjust) 100K Finger adjust spindle 4 plastic spacers, 3/8 in. (10 mm) Small prototype breadboard Terminal connector 4 push switches Motor Transistor 2 red LEDs, 3/16 in. (5 mm) 2 orange LEDs, 3/16 in. (5 mm) 2 yellow LEDs, 3/16 in. (5 mm) 2 green LEDs, 3/16 in. (5 mm) RGB LED, 3/16 in. (5 mm) Fan blade 5 2.2K resistors 5 10K resistors 10 220 resistors 20 male to male jumper wires 470uF electrolytic capacitor Piezo element buzzer 4 pan head M3 machine screws PhototransistorSpecifications Grades 2 and up WARNING: Choking Hazard. Small Parts. Not for children under 3 yrs."
# Test different pooling strategies
pooling_strategies = ['mean', 'cls', 'max']
for strategy in pooling_strategies:
    score = calculate_similarity(sentence1, sentence3, pooling_strategy=strategy)
    print(f'Similarity score ({strategy} pooling): {score}')

# Example with titles (Uncomment if needed)
# title1 = "Brown Dog Solar Bug 2.0"
# title2 = "Solar Bug, Pack of 25"
# title3 = "Science First Solar Motion Kit, Pack of 24"
# for strategy in pooling_strategies:
#     score = calculate_similarity(title1, title3, pooling_strategy=strategy)
#     print(f'Similarity score for titles ({strategy} pooling): {score}')